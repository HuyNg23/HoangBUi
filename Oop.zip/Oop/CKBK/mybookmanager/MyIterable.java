package hus.oop.mybookmanager;

public interface MyIterable {
    MyIterator iterator(int start);
}
