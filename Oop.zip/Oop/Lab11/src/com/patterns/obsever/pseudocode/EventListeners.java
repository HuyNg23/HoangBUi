package com.patterns.obsever.pseudocode;

public interface EventListeners {
    public void update(String filename);
}
