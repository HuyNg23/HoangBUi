package com.patterns.decorator.shape;

public interface Shape {
    void draw();
}