package com.patterns.decorator.icecream;

public interface IceCream {
    String getDescription();
}