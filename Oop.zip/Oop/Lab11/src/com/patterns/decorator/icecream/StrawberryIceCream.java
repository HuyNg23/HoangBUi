package com.patterns.decorator.icecream;

public class StrawberryIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Strawberry";
    }
}
