package com.patterns.iterator;


public interface Iterable {
    Iterator getIterator();
}
