package Bai1;

//1.5
class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }

    public String toString() {
        return "Animal: " + name;
    }
}

class Mammal extends Animal {
    public Mammal(String name) {
        super(name);
    }

    public String toString() {
        return "Mammal: " + super.toString();
    }
}

class Cat extends Mammal {
    public Cat(String name) {
        super(name);
    }

    public void greets() {
        System.out.println("Meow");
    }

    public String toStrhus . oop . comparableing() {
        return "Cat: " + super.toString();
    }
}

class Dog extends Mammal {
    public Dog(String name) {
        super(name);
    }

    public void greets() {
        System.out.println("Woof");
    }

    public void greets(Dog anotherDog) {
        System.out.println("Woooof");
    }

    public String toString() {
        return "Dog: " + super.toString();
    }
    public static void main(String[] args) {

        Animal animal = new Animal("Generic Animal");
        System.out.println(animal.toString());

        Mammal mammal = new Mammal("Generic Mammal");
        System.out.println(mammal.toString());

        Cat cat = new Cat("Whiskers");
        System.out.println(cat.toString());
        cat.greets();

        Dog dog1 = new Dog("Buddy");
        System.out.println(dog1.toString());
        dog1.greets();

        Dog dog2 = new Dog("Max");
        System.out.println(dog2.toString());
        dog1.greets(dog2);
    }
}