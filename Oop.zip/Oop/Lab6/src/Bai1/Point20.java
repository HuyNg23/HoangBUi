package Bai1;
//1.3

class Point20 {
    private float x;
    private float y;

    public Point20(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public Point20() {
        this(0.0f, 0.0f);
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setXY(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float[] getXY() {
        return new float[]{x, y};
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}

class Point30 extends Point20 {
    private float z;

    public Point30(float x, float y, float z) {
        super(x, y);
        this.z = z;
    }

    public Point30() {
        super();
        this.z = 0.0f;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    public void setXYZ(float x, float y, float z) {
        setXY(x, y);
        this.z = z;
    }

    public float[] getXYZ() {
        float[] xy = getXY();
        float[] xyz = {xy[0], xy[1], z};
        return xyz;
    }

    @Override
    public String toString() {
        return "(" + getX() + "," + getY() + "," + z + ")";
    }

    public static void main(String[] args) {
        Point20 point20 = new Point20(2.5f, 3.7f);
        System.out.println("Point20: " + point20.toString());
        point20.setX(4.2f);
        point20.setY(1.8f);
        System.out.println("New Point20: " + point20.toString());

        Point30 point30 = new Point30(1.0f, 2.0f, 3.0f);
        System.out.println("Point30: " + point30.toString());
        point30.setXYZ(4.0f, 5.0f, 6.0f);
        System.out.println("New Point30: " + point30.toString());

        float[] xy = point30.getXY();
        System.out.println("Point30 XY: (" + xy[0] + "," + xy[1] + ")");

        float[] xyz = point30.getXYZ();
        System.out.println("Point30 XYZ: (" + xyz[0] + "," + xyz[1] + "," + xyz[2] + ")");
    }
}