package Bai1;

public class Square extends Rectangle {
    public Square(double side) {
        super(side, side);
    }

    public void setSide(double side) {
        setLength(side);
        setWidth(side);
    }

    public double getSide() {
        return getLength(); // or getWidth()
    }

    public String toString() {
        return "A Square with side = " + getSide() + ", which is a subclass of " + super.toString();
    }
}