package Bai2;

public class TestLine {
    public static void main(String[] args) {
        // Create a line using constructor with coordinates
        Line line1 = new Line(0, 0, 3, 4);
        System.out.println("Line 1: " + line1);
        System.out.println("Length: " + line1.getLength());
        System.out.println("Gradient: " + line1.getGradient());

        // Create two points and use them to create a line
        Point point1 = new Point(1, 2);
        Point point2 = new Point(5, 6);
        Line line2 = new Line(point1, point2);

        // Print line information
        System.out.println("Line 2: " + line2);
        System.out.println("Length: " + line2.getLength());
        System.out.println("Gradient: " + line2.getGradient());

        // Set new coordinates for line2
        line2.setBeginX(0);
        line2.setBeginY(0);
        line2.setEndXY(2, 2);

        // Print updated line information
        System.out.println("Updated Line 2: " + line2);
        System.out.println("Length: " + line2.getLength());
        System.out.println("Gradient: " + line2.getGradient());
    }
}