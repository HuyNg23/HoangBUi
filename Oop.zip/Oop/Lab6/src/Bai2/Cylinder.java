package Bai2;

/**
 * Cylinder.java
 */
public class Cylinder {
    private Circle base;
    private double height;

    public Cylinder() {
        base = new Circle();
        height = 1.0;
    }

    public Cylinder(double radius, String color, double height) {
        base = new Circle(radius, color);
        this.height = height;
    }

    public double getRadius() {
        return base.getRadius();
    }

    public String getColor() {
        return base.getColor();
    }

    public double getHeight() {
        return height;
    }

    public void setRadius(double radius) {
        base.setRadius(radius);
    }

    public void setColor(String color) {
        base.setColor(color);
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getVolume() {
        return base.getArea() * height;
    }

    public double getSurfaceArea() {
        return 2 * base.getArea() + base.getCircumference() * height;
    }

    public String toString() {
        return "Cylinder: " + base + ", Height=" + height;
    }
    public static void main(String[] args) {
        // Tạo một đối tượng Cylinder
        Cylinder cylinder = new Cylinder(3.0, "blue", 5.0);

        // In ra thông tin về Cylinder
        System.out.println(cylinder.toString());

        // In ra diện tích bề mặt và thể tích của Cylinder
        System.out.println("Surface Area: " + cylinder.getSurfaceArea());
        System.out.println("Volume: " + cylinder.getVolume());
    }
}