package Test.bai2;

import java.util.Scanner;
public class HinhChuNhat{
    double chieuDai;
    double chieuRong;
    public void  getInformation(){
        Scanner sc = new Scanner(System.in);
        chieuDai = sc.nextDouble();
        chieuRong = sc.nextDouble();
    }
    public double Area(){
        return chieuDai * chieuRong;
    }
    public double Perimeter(){
        return  2*chieuDai + 2*chieuRong;
    }
    public void display(){
        System.out.println("Area:"+Area());
        System.out.println("Perimeter:"+Perimeter());
    }
    public static void main(String args[]){
        HinhChuNhat h1 = new HinhChuNhat();
        h1.getInformation();
        h1.display();
    }

}