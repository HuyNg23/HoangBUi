package Test.bai1;

import java.util.Scanner;
public class Student{
    String name;
    int age;
    public void display(){
        System.out.println("Name : " + name);
        System.out.println("Age : " + age);
    }
    public void getInformation(){
        Scanner sc = new Scanner(System.in);
        name = sc.next();
        age = sc.nextInt();
    }
    public static void main(String args[]){
        Student s1 = new Student();
        s1.getInformation();
        s1.display();
    }
}




