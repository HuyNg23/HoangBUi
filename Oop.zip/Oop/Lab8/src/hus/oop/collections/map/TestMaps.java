package hus.oop.collections.map;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
public class TestMaps {
    public static void main(String[] args) {
        // Example usage of the methods in the Maps class

        // Creating a map
        Map<Integer, Integer> map = new HashMap<>();
        map.put(1, 10);
        map.put(2, 20);
        map.put(3, 30);
        System.out.println("Map: " + map);

        // Counting the number of key-value mappings of the map
        int count = Maps.count(map);
        System.out.println("Number of mappings: " + count);

        // Removing all mappings from the map
        Maps.empty(map);
        System.out.println("Map after emptying: " + map);

        // Adding new mappings to the map
        map.put(4, 40);
        map.put(5, 50);
        map.put(6, 60);
        System.out.println("Map after adding new mappings: " + map);

        // Checking if the map contains a mapping for the specified key
        int key = 5;
        boolean containsKey = Maps.contains(map, key);
        System.out.println("Map contains key " + key + ": " + containsKey);

        // Checking if the map contains a mapping for the specified key and value
        int value = 50;
        boolean containsKeyValue = Maps.containsKeyValue(map, key, value);
        System.out.println("Map contains key-value (" + key + ", " + value + "): " + containsKeyValue);

        // Getting the key set of the map
        Set<Integer> keySet = Maps.keySet(map);
        System.out.println("Key set: " + keySet);

        // Getting the values of the map
        Collection<Integer> values = Maps.values(map);
        System.out.println("Values: " + values);

        // Getting the color based on an input value
        int colorValue = 1;
        String color = Maps.getColor(colorValue);
        System.out.println("Color for value " + colorValue + ": " + color);
    }
}
