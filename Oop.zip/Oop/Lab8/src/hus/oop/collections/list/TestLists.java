package hus.oop.collections.list;

import java.util.*;

public class TestLists{
    public static void main(String[] args) {
        List<Integer> myList = new ArrayList<>();
        LinkedList<Integer> myLinkedList = new LinkedList<>();

        // Testing insertFirst
        Lists.insertFirst(myList, 10);
        System.out.println("After insertFirst: " + myList); // Output: [10]

        // Testing insertLast
        Lists.insertLast(myList, 20);
        System.out.println("After insertLast: " + myList); // Output: [10, 20]

        // Testing replace
        Lists.replace(myList, 30);
        System.out.println("After replace: " + myList); // Output: [10, 20, 30]

        // Testing removeThird
        Lists.removeThird(myList);
        System.out.println("After removeThird: " + myList); // Output: [10, 20]

        // Testing removeEvil
        myList.add(666);
        myList.add(50);
        Lists.removeEvil(myList);
        System.out.println("After removeEvil: " + myList); // Output: [10, 20, 50]

        // Testing generateSquare
        List<Integer> squareList = Lists.generateSquare();
        System.out.println("Square list: " + squareList); // Output: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

        // Testing contains
        boolean containsValue = Lists.contains(squareList, 25);
        System.out.println("Contains 25? " + containsValue); // Output: true

        // Testing copy
        List<Integer> targetList = new ArrayList<>();
        Lists.copy(squareList, targetList);
        System.out.println("Target list after copy: " + targetList); // Output: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

        // Testing reverse
        Lists.reverse(targetList);
        System.out.println("Reversed target list: " + targetList); // Output: [100, 81, 64, 49, 36, 25, 16, 9, 4, 1]

        // Testing reverseManual
        Lists.reverseManual(targetList);
        System.out.println("Manually reversed target list: " + targetList); // Output: [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

        // Testing insertBeginningEnd
        Lists.insertBeginningEnd(myLinkedList, 5);
        System.out.println("Linked list after insertBeginningEnd: " + myLinkedList); // Output: [5, 5]
    }
}