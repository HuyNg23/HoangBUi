package hus.oop.collections.set;

import java.util.*;

public class TestSets {
    public static void main(String[] args) {
        // Example usage of the methods in the Sets class

        // Creating two sets
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6, 7, 8));

        // Intersection of two sets
        Set<Integer> intersection = Sets.intersectionManual(set1, set2);
        System.out.println("Intersection: " + intersection);

        // Union of two sets
        Set<Integer> union = Sets.unionManual(set1, set2);
        System.out.println("Union: " + union);

        // Transforming a set into a list without duplicates
        List<Integer> list = Sets.toList(set1);
        System.out.println("List: " + list);

        // Removing duplicates from a list
        List<Integer> listWithoutDuplicates = Sets.removeDuplicates(list);
        System.out.println("List without duplicates: " + listWithoutDuplicates);

        // Removing duplicates from a list manually
        List<Integer> listWithoutDuplicatesManual = Sets.removeDuplicatesManual(list);
        System.out.println("List without duplicates (manual): " + listWithoutDuplicatesManual);

        // Finding the first recurring character in a string
        String str = "abca";
        Character recurringChar = Sets.firstRecurringCharacter(str);
        System.out.println("First recurring character: " + recurringChar);

        // Finding all recurring characters```java
        Set<Character> recurringChars = Sets.allRecurringChars(str);
        System.out.println("All recurring characters: " + recurringChars);

        // Transforming a set into an array
        Set<Integer> set3 = new HashSet<>(Arrays.asList(1, 2, 3));
        Integer[] array = Sets.toArray(set3);
        System.out.println("Array: " + Arrays.toString(array));

        // Getting the first item from a TreeSet
        TreeSet<Integer> treeSet = new TreeSet<>(Arrays.asList(3, 2, 1));
        int first = Sets.getFirst(treeSet);
        System.out.println("First item: " + first);

        // Getting the last item from a TreeSet
        int last = Sets.getLast(treeSet);
        System.out.println("Last item: " + last);

        // Getting an element from a TreeSet greater than a given value
        int value = 2;
        int greater = Sets.getGreater(treeSet, value);
        System.out.println("Greater than " + value + ": " + greater);
    }
}
