package hus.oop.comparator;


/**
 * A Java program to demonstrate the use of Comparator interface
 */
class Movie implements Comparable<Movie> {
    private String name;
    private double rating;
    private int year;

    // Used to sort movies by year
    public int compareTo(Movie movie) {
        return this.year - movie.year;
    }

    // Constructor
    public Movie(String name, double rating, int year) {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    // Getter methods for accessing private data
    public double getRating() {
        return rating;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }
}

