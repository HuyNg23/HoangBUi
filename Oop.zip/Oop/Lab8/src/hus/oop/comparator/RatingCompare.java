package hus.oop.comparator;


import java.util.Comparator;

/**
 * Class to compare movies by ratings
 */
class RatingCompare implements Comparator<Movie> {
    public int compare(Movie left, Movie right) {
        if (left.getRating() < right.getRating()) {
            return -1;
        } else if (left.getRating() > right.getRating()) {
            return 1;
        }
        return 0;
    }
}
