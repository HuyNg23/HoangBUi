/*package hus.oop.mylist;

public class TestMyList {
    private static Object Assertions;

    public static void main(String[] args) {
        /*
         * TODO
         * Chạy demo các hàm test.
         */


/*
    public static void testMyArrayList() {
        private MyArrayList list;

        @BeforeEach
        void setUp() {
            list = new MyArrayList();
        }

        @Test
        void testSize() {
            Assertions.assertEquals(0, list.size());
            list.append(1.0);
            Assertions.assertEquals(1, list.size());
            list.append(2.0);
            Assertions.assertEquals(2, list.size());
        }

        @Test
        void testGet() {
            list.append(1.0);
            list.append(2.0);
            list.append(3.0);
            Assertions.assertEquals(1.0, list.get(0));
            Assertions.assertEquals(2.0, list.get(1));
            Assertions.assertEquals(3.0, list.get(2));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.get(-1));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.get(3));
        }

        @Test
        void testRemove() {
            list.append(1.0);
            list.append(2.0);
            list.append(3.0);
            Assertions.assertEquals(3, list.size());
            list.remove(1);
            Assertions.assertEquals(2, list.size());
            Assertions.assertEquals(1.0, list.get(0));
            Assertions.assertEquals(3.0, list.get(1));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.remove(-1));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.remove(3));
        }

        @Test
        void testAppend() {
            list.append(1.0);
            list.append(2.0);
            list.append(3.0);
            Assertions.assertEquals(3, list.size());
            Assertions.assertEquals(1.0, list.get(0));
            Assertions.assertEquals(2.0, list.get(1));
            Assertions.assertEquals(3.0, list.get(2));
        }

        @Test
        void testInsert() {
            list.insert(1.0, 0);
            Assertions.assertEquals(1, list.size());
            Assertions.assertEquals(1.0, list.get(0));
            list.insert(2.0, 0);
            Assertions.assertEquals(2, list.size());
            Assertions.assertEquals(2.0, list.get(0));
            Assertions.assertEquals(1.0, list.get(1));
            list.insert(3.0, 2);
            Assertions.assertEquals(3, list.size());
            Assertions.assertEquals(2.0, list.get(0));
            Assertions.assertEquals(1.0, list.get(1));
            Assertions.assertEquals(3.0, list.get(2));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.insert(4.0, -1));
            Assertions.assertThrows(IndexOutOfBoundsException.class, () -> list.insert(4.0, 4));
        }

        @Test
        void testIterator() {
            list.append(1.0);
            list.append(2.0);
            list.append(3.0);
            MyIterator iterator = list.iterator();
            Assertions.assertTrue(iterator.hasNext());
            Assertions.assertEquals(1.0, iterator.next());
            Assertions.assertTrue(iterator.hasNext());
            Assertions.assertEquals(2.0, iterator.next());
            Assertions.assertTrue(iterator.hasNext());
            Assertions.assertEquals(3.0, iterator.next());
            Assertions.assertFalse(iterator.hasNext());
        }
    }

    public static void testMyLinkedList() {
        // Create a MyLinkedList with Double elements
        MyLinkedList myLinkedList = new MyLinkedList();

        // Add some elements to the list
        myLinkedList.append(10.5);
        myLinkedList.append(15.2);
        myLinkedList.append(8.7);
        myLinkedList.append(12.1);
        myLinkedList.append(9.3);

        // Print the list
        System.out.println("MyLinkedList contents:");
        MyIterator iterator = myLinkedList.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();

        // Calculate basic statistics using BasicStatistic
        BasicStatistic<Double> basicStatistic = new BasicStatistic<>();
        for (int i = 0; i < myLinkedList.size(); i++) {
            basicStatistic.addData((Double)myLinkedList.get(i));
        }

        System.out.println("Basic statistics:");
        System.out.println("Max: " + basicStatistic.getMax());
        System.out.println("Min: " + basicStatistic.getMin());
        System.out.println("Mean: " + basicStatistic.getMean());
        System.out.println("Variance: " + basicStatistic.getVariance());
    }
}
*/