package com.oop.collections.polynomials;

import java.util.Arrays;
import java.util.Objects;

public abstract class AbstractPoly implements Poly {

    double[] derive() {
        double[] derivedCoefficients = new double[degree()];
        for (int i = 1; i <= degree(); i++) {
            derivedCoefficients[i - 1] = i * coefficient(i);
        }
        return derivedCoefficients;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AbstractPoly that = (AbstractPoly) o;
        return Arrays.equals(coefficients(), that.coefficients());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(coefficients());
    }

    @Override
    public String toString() {
        int degree = degree();
        StringBuilder sb = new StringBuilder();
        for (int i = degree; i >= 0; i--) {
            double coeff = coefficient(i);
            if (coeff != 0) {
                if (sb.length() > 0) {
                    if (coeff > 0) {
                        sb.append(" + ");
                    } else {
                        sb.append(" - ");
                        coeff = Math.abs(coeff);
                    }
                } else if (coeff < 0) {
                    sb.append("-");
                    coeff = Math.abs(coeff);
                }
                if (i == 0 || coeff != 1) {
                    sb.append(coeff);
                }
                if (i > 0) {
                    sb.append("x");
                    if (i > 1) {
                        sb.append("^").append(i);
                    }
                }
            }
        }
        return sb.toString();
    }
}

