
package com.oop.collections.polynomials;
import java.util.List;
import java.util.ArrayList;

public class ListPoly extends AbstractPoly {

    private final List<Double> coefficients;

    public ListPoly(double[] coeffs) {
        this.coefficients = new ArrayList<>();
        for (double coeff : coeffs) {
            this.coefficients.add(coeff);
        }
    }

    @Override
    public int degree() {
        return coefficients.size() -1;
    }

    @Override
    public Poly derivative() {
        double[] derivedCoefficients = derive();
        return new ListPoly(derivedCoefficients);
    }

    @Override
    public double coefficient(int degree) {
        if (degree >= 0 && degree < coefficients.size()) {
            return coefficients.get(degree);
        }
        return 0;
    }

    @Override
    public double[] coefficients() {
        double[] coeffs = new double[coefficients.size()];
        for (int i = 0; i < coeffs.length; i++) {
            coeffs[i] = coefficients.get(i);
        }
        return coeffs;
    }
}
