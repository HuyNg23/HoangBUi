package com.oop.collections.polynomials;

import java.util.Arrays;

public class ArrayPoly extends AbstractPoly {

    private final double[] coefficients;

    public ArrayPoly(double[] coefficients) {
        this.coefficients = Arrays.copyOf(coefficients, coefficients.length);
    }

    @Override
    public int degree() {
        return coefficients.length - 1;
    }

    @Override
    public Poly derivative() {
        double[] derivedCoefficients = derive();
        return new ArrayPoly(derivedCoefficients);
    }

    @Override
    public double coefficient(int degree) {
        if (degree >= 0 && degree < coefficients.length) {
            return coefficients[degree];
        }
        return 0;
    }

    @Override
    public double[] coefficients() {
        return Arrays.copyOf(coefficients, coefficients.length);
    }
}
