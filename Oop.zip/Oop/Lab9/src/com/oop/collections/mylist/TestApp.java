package com.oop.collections.mylist;

public class TestApp {
    public static void main(String[] args) {
        MyList list = new MyLinkedList();
        list.add("a", 0);
        list.add("b");
        list.add("c", 0);
        list.add("d", 2);
        list.add("e");

        System.out.println("List size: " + list.size());
        System.out.println("List elements: " + list);

        list.remove(2);
        System.out.println("After removing element at index 2:");
        System.out.println("List size: " + list.size());
        System.out.println("List elements: " + list);

        Object element = list.get(1);
        System.out.println("Element at index 1: " + element);
    }
}