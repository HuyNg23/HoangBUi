package com.oop.collections.phonebook;

import java.util.ArrayList;
import java.util.List;

public class PhoneBookList implements PhoneBook {
    private List<Student> phoneBook;

    public PhoneBookList() {
        phoneBook = new ArrayList<>();
    }

    @Override
    public void addPerson(Student student) {
        phoneBook.add(student);
    }

    @Override
    public void deleteByNumber(String phoneNumber) {
        Student studentToRemove = null;
        for (Student student : phoneBook) {
            if (student.getPhone().equals(phoneNumber)) {
                studentToRemove = student;
                break;
            }
        }
        if (studentToRemove != null) {
            phoneBook.remove(studentToRemove);
        }
    }

    @Override
    public Student searchByName(String name) {
        for (Student student : phoneBook) {
            if (student.getName().equals(name)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public Student searchByLastname(String lastname) {
        for (Student student : phoneBook) {
            if (student.getLastname().equals(lastname)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public Student searchByNumber(String phoneNumber) {
        for (Student student : phoneBook) {
            if (student.getPhone().equals(phoneNumber)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(phoneBook);
    }
}