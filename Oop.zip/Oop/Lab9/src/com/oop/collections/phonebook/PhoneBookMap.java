package com.oop.collections.phonebook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PhoneBookMap implements PhoneBook {
    private Map<String, Student> phoneBook;

    public PhoneBookMap() {
        phoneBook = new HashMap<>();
    }

    @Override
    public void addPerson(Student student) {
        phoneBook.put(student.getPhone(), student);
    }

    @Override
    public void deleteByNumber(String phoneNumber) {
        phoneBook.remove(phoneNumber);
    }

    @Override
    public Student searchByName(String name) {
        for (Student student : phoneBook.values()) {
            if (student.getName().equals(name)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public Student searchByLastname(String lastname) {
        for (Student student : phoneBook.values()) {
            if (student.getLastname().equals(lastname)) {
                return student;
            }
        }
        return null;
    }

    @Override
    public Student searchByNumber(String phoneNumber) {
        return phoneBook.get(phoneNumber);
    }

    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(phoneBook.values());
    }
}