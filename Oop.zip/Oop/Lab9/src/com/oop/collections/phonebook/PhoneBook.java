package com.oop.collections.phonebook;

import java.util.List;

public interface PhoneBook {
    void addPerson(Student student);
    void deleteByNumber(String phoneNumber);
    Student searchByName(String name);
    Student searchByLastname(String lastname);
    Student searchByNumber(String phoneNumber);
    List<Student> getAllStudents();
}