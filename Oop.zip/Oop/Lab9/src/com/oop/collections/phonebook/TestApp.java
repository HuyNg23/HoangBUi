package com.oop.collections.phonebook;

import java.util.ArrayList;
import java.util.List;

public class TestApp {
    public static void main(String[] args) {
        PhoneBook pb = new PhoneBookMap();
        // Comment this line for switching implementation
        // PhoneBook pb = new PhoneBookList();
        pb.addPerson(new Student("Nicola", "Bicocchi", "34567"));
        pb.addPerson(new Student("Marco", "Rizzo", "45243"));
        pb.addPerson(new Student("Luisa", "Verdi", "98765"));

        System.out.println("Phone book entries:");
        displayPhoneBook(pb);

        System.out.println("\nSearch by name:");
        Student studentByName = pb.searchByName("Marco");
        if (studentByName != null) {
            System.out.println(studentByName.getName());
        } else {
            System.out.println("Student not found.");
        }

        System.out.println("\nSearch by lastname:");
        Student studentByLastname = pb.searchByLastname("Bicocchi");
        if (studentByLastname != null) {
            System.out.println(studentByLastname.getName());
        } else {
            System.out.println("Student not found.");
        }

        System.out.println("\nSearch by phone number:");
        Student studentByPhone = pb.searchByNumber("98765");
        if (studentByPhone != null) {
            System.out.println(studentByPhone.getName());
        } else {
            System.out.println("Student not found.");
        }

        System.out.println("\nDelete by phone number:");
        pb.deleteByNumber("34567");
        displayPhoneBook(pb);
    }

    private static void displayPhoneBook(PhoneBook pb) {
        List<Student> students = pb.getAllStudents();
        if (students.isEmpty()) {
            System.out.println("Phone book is empty.");
        } else {
            for (Student student : students) {
                System.out.println(student.getName());
            }
        }
    }
}