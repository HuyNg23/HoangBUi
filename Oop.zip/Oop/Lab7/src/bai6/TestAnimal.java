package bai6;

public class TestAnimal {
	public static void main(String[] args) {
		Animal meow1 = new Cat("Kitty");
		meow1.greets();
		
		Animal dog1 = new Dog("Bull");
		dog1.greets();
		Dog dog2 = new Dog("Bug");
		dog2.greets((Dog) dog1);
		
		Animal bigDog1 = new BigDog("Shiba");
		bigDog1.greets();
	}
}
