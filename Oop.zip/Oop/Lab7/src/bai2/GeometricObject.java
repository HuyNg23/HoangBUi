package bai2;

public interface GeometricObject {
	public double getArea();
	
	public double getPerimeter();
}
