package bai2;

public class TestGeometricObject {
	public static void main(String[] args) { 
		GeometricObject a = new Rectangle(3.5, 4.0);
		System.out.println(a);
		System.out.println(a.getPerimeter());
	}
}
