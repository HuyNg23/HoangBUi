package bai5;

public class TestGeometricObject {
	public static void main(String[] args) {
		GeometricObject c1 = new Circle(2.2);
		System.out.println(c1);
		System.out.println("c1's perimeter is: " + c1.getPerimeter());
		System.out.println("c1's area is: " + c1.getArea());
		
		GeometricObject c2 = new ResizableCircle(2.2);
		System.out.println(c2);
		
		Resizable c3 = new ResizableCircle(2.2);
		c3.resize(50);
		System.out.println(c3);
	}
}
