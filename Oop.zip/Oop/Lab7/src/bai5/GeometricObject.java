package bai5;

public interface GeometricObject {
	public double getPerimeter();
	
	public double getArea();
}
