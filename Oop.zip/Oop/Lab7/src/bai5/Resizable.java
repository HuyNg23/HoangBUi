package bai5;

public interface Resizable {
	public void resize(int percent);
}
