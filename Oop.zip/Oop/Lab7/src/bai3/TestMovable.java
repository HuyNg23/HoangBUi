package bai3;

public class TestMovable {
	public static void main(String[] args) {
		Movable a = new MovablePoint(1, 2, 3, 4);
		System.out.println(a);
		a.moveDown(); //test moveDown() method
		System.out.println(a);
	}
}
