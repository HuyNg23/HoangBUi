package bai4;

public class TestMovable {
	public static void main(String[] args) {
		Movable a = new MovablePoint(1, 2, 3, 4);
		System.out.println(a);
		
		Movable b = new MovableCircle(1, 2, 3, 4, 5);
		System.out.println(b);
		b.moveRight(); // x += xSpeed;
		System.out.println(b);
		
	}
}
