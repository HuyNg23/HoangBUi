package bai7;

public abstract class Animal {
	abstract public void greeting();
}
