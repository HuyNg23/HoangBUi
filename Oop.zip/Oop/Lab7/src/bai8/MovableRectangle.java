package bai8;

public class MovableRectangle implements Movable {
	private MovablePoint topLeft;
	private MovablePoint bottomRight;
	
	public MovableRectangle(int x1, int y1, int x2, int y2, int xSpeed, int ySpeed) {
		topLeft = new MovablePoint(x1, y1, xSpeed, ySpeed);
		bottomRight = new MovablePoint(x2, y2, xSpeed, ySpeed);
	}
	
	public String toString() {
		return String.format("MovableRectangle[topLeft = %1$s, bottomRight = %2$s]", topLeft.toString(), bottomRight.toString());
	}
	
	public boolean haveTheSameSpeed() {
		return (topLeft.xSpeed == bottomRight.xSpeed) && (topLeft.ySpeed == bottomRight.ySpeed);
	}
	
	@Override 
	public void moveUp() {
		if (! haveTheSameSpeed()) {
			return;
		}
		topLeft.y -= topLeft.ySpeed;
		bottomRight.y -= bottomRight.ySpeed;
	}
	
	@Override
	public void moveDown() {
		if (! haveTheSameSpeed()) {
			return;
		}
		topLeft.y += topLeft.ySpeed;
		bottomRight.y += bottomRight.ySpeed;
	}
	
	@Override 
	public void moveLeft() {
		if (! haveTheSameSpeed()) {
			return;
		}
		topLeft.x -= topLeft.xSpeed;
		bottomRight.x -= bottomRight.xSpeed;
	}
	
	@Override
	public void moveRight() {
		if (! haveTheSameSpeed()) {
			return;
		}
		topLeft.x += topLeft.xSpeed;
		bottomRight.x += bottomRight.xSpeed;
	}
}
