// bai 1.2
public class TestMyPolynomial {
    public static void main(String[] args) {
        MyPolynomial polynomial1 = new MyPolynomial(1.1, 2.2, 3.3);
        MyPolynomial polynomial2 = new MyPolynomial(1.2, 3.4, 5.6, 7.8);
        MyPolynomial polynomial3 = new MyPolynomial(1.2, 2.3, 3.4, 4.5, 5.6);

        System.out.println("Đa thức 1: " + polynomial1.toString());
        System.out.println("Bậc của đa thức 1: " + polynomial1.getDegree());
        System.out.println("Giá trị của đa thức 1 tại x = 1: " + polynomial1.evaluate(1));

        System.out.println("\nĐa thức 2: " + polynomial2.toString());
        System.out.println("Bậc của đa thức 2: " + polynomial2.getDegree());
        System.out.println("Giá trị của đa thức 2 tại x = 2: " + polynomial2.evaluate(2));

        System.out.println("\nĐa thức 3: " + polynomial3.toString());
        System.out.println("Bậc của đa thức 3: " + polynomial3.getDegree());
        System.out.println("Giá trị của đa thức 3 tại x = 3: " + polynomial3.evaluate(3));

        MyPolynomial sum = polynomial1.add(polynomial2);
        System.out.println("\nTổng của đa thức 1 và đa thức 2: " + sum.toString());

        MyPolynomial product = polynomial2.multiply(polynomial3);
        System.out.println("Tích của đa thức 2 và đa thức 3: " + product.toString());
    }
}