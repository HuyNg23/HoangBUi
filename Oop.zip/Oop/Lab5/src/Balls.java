public class Balls {
    private double x;
    private double y;
    private double speed;
    private double direction;

    public Balls(double x, double y, double speed, double direction) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.direction = direction;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getSpeed() {
        return speed;
    }

    public double getDirection() {
        return direction;
    }

    public void move() {
        double xDelta = speed * Math.cos(Math.toRadians(direction));
        double yDelta = speed * Math.sin(Math.toRadians(direction));
        x += xDelta;
        y += yDelta;
    }

    public void kick(double speed, double direction) {
        this.speed = speed;
        this.direction = direction;
    }

    public String toString() {
        return "Ball position: (" + x + ", " + y + ")";
    }
}