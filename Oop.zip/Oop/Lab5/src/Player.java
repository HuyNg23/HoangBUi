public class Player {
    private String name;
    private int number;

    public Player(String name, int number) {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public void kickBall(Balls ball, double speed, double direction) {
        ball.kick(speed, direction);
    }
}