public class TestProgram {
    public static void main(String[] args) {
        MyDate date = new MyDate(2011, 12, 28);
        MyDate endDate = new MyDate(2012, 3, 2);

        while (!date.equals(endDate)) {
            System.out.println(date);
            date.nextDay();
        }
        System.out.println(endDate);
    }
}

class MyDate {
    private int year;
    private int month;
    private int day;

    public static final String[] MONTHS = {
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };

    public static final String[] DAYS = {
            "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
    };

    public static final int[] DAY_IN_MONTHS = {
            31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };

    public MyDate(int year, int month, int day) {
        setDate(year, month, day);
    }

    public boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    public boolean isValidDate(int year, int month, int day) {
        if (year < 1 || year > 9999 || month < 1 || month > 12) {
            return false;
        }

        int maxDay = DAY_IN_MONTHS[month - 1];
        if (month == 2 && isLeapYear(year)) {
            maxDay = 29;
        }

        return day >= 1 && day <= maxDay;
    }

    public int getDayOfWeek(int year, int month, int day) {
        if (!isValidDate(year, month, day)) {
            throw new IllegalArgumentException("Invalid year, month, or day!");
        }

        if (month < 3) {
            month += 12;
            year--;
        }

        int century = year / 100;
        year %= 100;

        int h = day + 2 * month + 3 * (month + 1) / 5 + year + year / 4 + century / 4 - 2 * century;
        h %= 7;
        if (h < 0) {
            h += 7;
        }

        return h;
    }

    public void setDate(int year, int month, int day) {
        if (!isValidDate(year, month, day)) {
            throw new IllegalArgumentException("Invalid year, month, or day!");
        }

        this.year = year;
        this.month = month;
        this.day = day;
    }

    public void setYear(int year) {
        if (year < 1 || year > 9999) {
            throw new IllegalArgumentException("Invalid year!");
        }

        this.year = year;
    }

    public void setMonth(int month) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Invalid month!");
        }

        this.month = month;
    }

    public void setDay(int day) {
        int maxDay = DAY_IN_MONTHS[month - 1];
        if (month == 2 && isLeapYear(year)) {
            maxDay = 29;
        }

        if (day < 1 || day > maxDay) {
            throw new IllegalArgumentException("Invalid day!");
        }

        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public String toString() {
        String dayOfWeek = DAYS[getDayOfWeek(year, month, day)];
        return dayOfWeek + " " + day + " " + MONTHS[month - 1] + " " + year;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        MyDate other = (MyDate) obj;
        return year == other.year && month == other.month && day == other.day;
    }

    public MyDate nextDay() {
        if (day == DAY_IN_MONTHS[month - 1]) {
            if (month == 12) {
                year++;
                month = 1;
            } else {
                month++;
                day = 1;
            }
        } else {
            day++;
        }

        return this;
    }
}