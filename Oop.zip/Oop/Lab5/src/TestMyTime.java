// bai  1.4
public class TestMyTime {
    public static void main(String[] args) {
        MyTime time = new MyTime();

        // Kiểm tra phương thức setTime và toString
        time.setTime(12, 30, 45);
        System.out.println(time.toString()); // Kết quả: 12:30:45

        // Kiểm tra phương thức setHour, setMinute, setSecond
        time.setHour(10);
        time.setMinute(20);
        time.setSecond(30);
        System.out.println(time.toString()); // Kết quả: 10:20:30

        // Kiểm tra phương thức getHour, getMinute, getSecond
        int hour = time.getHour();
        int minute = time.getMinute();
        int second = time.getSecond();
        System.out.println("Giờ: " + hour + ", Phút: " + minute + ", Giây: " + second); // Kết quả: Giờ: 10, Phút: 20, Giây: 30

        // Kiểm tra các phương thức nextSecond, nextMinute, nextHour
        time.nextSecond();
        System.out.println(time.toString()); // Kết quả: 10:20:31

        time.nextMinute();
        System.out.println(time.toString()); // Kết quả: 10:21:31

        time.nextHour();
        System.out.println(time.toString()); // Kết quả: 11:21:31


        // Kiểm tra các phương thức previousSecond, previousMinute, previousHour
        time.previousSecond();
        System.out.println(time.toString()); // Kết quả: 11:21:30

        time.previousMinute();
        System.out.println(time.toString()); // Kết quả: 11:20:30

        time.previousHour();
        System.out.println(time.toString()); // Kết quả: 10:20:30
    }
}