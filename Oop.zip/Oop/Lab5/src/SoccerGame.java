// 1.7
public class SoccerGame {
    public static void main(String[] args) {
        // Create the ball
        Balls ball = new Balls(0, 0, 0, 0);

        // Create the players
        Player player1 = new Player("Player 1", 1);
        Player player2 = new Player("Player 2", 2);
        Player player3 = new Player("Player 3", 3);
        Player player4 = new Player("Player 4", 4);

        // Set up the teams
        Player[] team1 = {player1, player2};
        Player[] team2 = {player3, player4};

        // Start the game
        System.out.println("Soccer game starts!");

        // Simulate the game
        for (int i = 0; i < 5; i++) {
            // Team 1 kicks the ball
            Player kicker = team1[i % 2];
            kicker.kickBall(ball, 10, 45);

            // Move the ball
            ball.move();

            // Print the ball's position
            System.out.println(ball);
        }

        // End the game
        System.out.println("Soccer game ends!");
    }
}