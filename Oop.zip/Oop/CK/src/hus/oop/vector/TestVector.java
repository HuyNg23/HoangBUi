package hus.oop.vector;

import java.util.Random;

public class TestVector {
    public static void main(String[] args) {
        Random random = new Random();
        int n = random.nextInt(10) + 1; // Sinh ngẫu nhiên số tự nhiên từ 1 đến 10

        MyArrayVector arrayVector1 = new MyArrayVector();
        MyArrayVector arrayVector2 = new MyArrayVector();
        MyListVector listVector1 = new MyListVector();
        MyListVector listVector2 = new MyListVector();

        // Sinh ngẫu nhiên csac phần tử cho các vector
        for (int i = 0; i < n; i++) {
            arrayVector1.insert(random.nextDouble() * 10);
            arrayVector2.insert(random.nextDouble() * 10);
            listVector1.insert(random.nextDouble() * 10);
            listVector2.insert(random.nextDouble() * 10);
        }

        // In các vector ban đầu
        System.out.println("Initial Vectors:");
        System.out.println("arrayVector1: " + arrayVector1);
        System.out.println("arrayVector2: " + arrayVector2);
        System.out.println("listVector1: " + listVector1);
        System.out.println("listVector2: " + listVector2);

        // Test thêm phần tử:
        arrayVector1.insert(5.5);
        listVector1.insert(6.6);
        System.out.println("\nAfter inserting elements:");
        System.out.println("arrayVector1: " + arrayVector1);
        System.out.println("listVector1: " + listVector1);

        // Test xóa phần tử:
        arrayVector1.remove(0);
        listVector1.remove(0);
        System.out.println("\nAfter removing elements:");
        System.out.println("arrayVector1: " + arrayVector1);
        System.out.println("listVector1: " + listVector1);

        // Test sửa giá trị phần tử
        arrayVector1.set(9.9, 0);
        listVector1.set(8.8, 0);
        System.out.println("\nAfter setting elements:");
        System.out.println("arrayVector1: " + arrayVector1);
        System.out.println("listVector1: " + listVector1);

        // Test cộng vector với vô hướng
        MyArrayVector arrayVector1AddScalar = arrayVector1.add(2.2);
        MyListVector listVector1AddScalar = listVector1.add(3.3);
        System.out.println("\nAfter adding scalar:");
        System.out.println("arrayVector1AddScalar: " + arrayVector1AddScalar);
        System.out.println("listVector1AddScalar: " + listVector1AddScalar);

        // Test cộng hai vector
        MyArrayVector arrayVectorSum = arrayVector1.add(arrayVector2);
        MyListVector listVectorSum = listVector1.add(listVector2);
        System.out.println("\nAfter adding vectors:");
        System.out.println("arrayVectorSum: " + arrayVectorSum);
        System.out.println("listVectorSum: " + listVectorSum);

        // Test nhân vector với vô hướng
        MyArrayVector arrayVectorScaled = arrayVector1.scale(2.0);
        MyListVector listVectorScaled = listVector1.scale(2.0);
        System.out.println("\nAfter scaling vectors:");
        System.out.println("arrayVectorScaled: " + arrayVectorScaled);
        System.out.println("listVectorScaled: " + listVectorScaled);

        // Test tích vô hướng hai vector
        double arrayVectorDotProduct = arrayVector1.dot(arrayVector2);
        double listVectorDotProduct = arrayVector1.dot(listVector2);
        System.out.println("\nDot product of vectors:");
        System.out.println("arrayVectorDotProduct: " + arrayVectorDotProduct);
        System.out.println("listVectorDotProduct: " + listVectorDotProduct);

        // Test chuẩn vector
        double arrayVectorNorm = arrayVector1.norm();
        double listVectorNorm = arrayVector1.norm();
        System.out.println("\nNorm of vectors:");
        System.out.println("arrayVectorNorm: " + arrayVectorNorm);
        System.out.println("listVectorNorm: " + listVectorNorm);
    }
}
