package hus.oop.vector;

import java.util.ArrayList;
import java.util.List;

public class MyListVector extends AbstractMyVector {
    private List<Double> data;

    /**
     * Khởi tạo mặc định cho vector.
     */
    public MyListVector() {
        this.data = new ArrayList<>();
    }

    /**
     * Khởi tạo vector dữ liệu ban đầu
     * @param data
     */
    public MyListVector(List<Double> data) {
        this.data = new ArrayList<>(data);
    }

    @Override
    public int size() {
        return data.size();
    }

    @Override
    public double coordinate(int index) {
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return data.get(index);
    }

    @Override
    public double[] coordinates() {
        double[] coords = new double[size()];
        for (int i = 0; i < size(); i++) {
            coords[i] = data.get(i);
        }
        return coords;
    }

    @Override
    public void set(double value, int index) {
        if (index < 0 || index >= size()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        data.set(index, value);
    }

    @Override
    public MyListVector add(double value) {
        List<Double> newData = new ArrayList<>();
        for (double d : data) {
            newData.add(d + value);
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector add(MyVector another) {
        if (size() != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        List<Double> newData = new ArrayList<>();
        for (int i = 0; i < size(); i++) {
            newData.add(data.get(i) + another.coordinate(i));
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector addTo(double value) {
        for (int i = 0; i < size(); i++) {
            data.set(i, data.get(i) + value);
        }
        return this;
    }

    @Override
    public MyListVector addTo(MyVector another) {
        if (size() != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        for (int i = 0; i < size(); i++) {
            data.set(i, data.get(i) + another.coordinate(i));
        }
        return this;
    }

    @Override
    public MyListVector minus(double value) {
        List<Double> newData = new ArrayList<>();
        for (double d : data) {
            newData.add(d - value);
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector minus(MyVector another) {
        if (size() != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        List<Double> newData = new ArrayList<>();
        for (int i = 0; i < size(); i++) {
            newData.add(data.get(i) - another.coordinate(i));
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector minusFrom(double value) {
        List<Double> newData = new ArrayList<>();
        for (double d : data) {
            newData.add(value - d);
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector minusFrom(MyVector another) {
        if (size() != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        List<Double> newData = new ArrayList<>();
        for (int i = 0; i < size(); i++) {
            newData.add(another.coordinate(i) - data.get(i));
        }
        return new MyListVector(newData);
    }

    @Override
    public double dot(MyVector another) {
        if (size() != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        double result = 0;
        for (int i = 0; i < size(); i++) {
            result += data.get(i) * another.coordinate(i);
        }
        return result;
    }

    @Override
    public MyListVector pow(double power) {
        List<Double> newData = new ArrayList<>();
        for (double d : data) {
            newData.add(Math.pow(d, power));
        }
        return new MyListVector(newData);
    }

    @Override
    public MyListVector scale(double value) {
        List<Double> newData = new ArrayList<>();
        for (double d : data) {
            newData.add(d * value);
        }
        return new MyListVector(newData);
    }

    @Override
    public double norm() {
        double sum = 0;
        for (double d : data) {
            sum += d * d;
        }
        return Math.sqrt(sum);
    }

    @Override
    public MyListVector insert(double value) {
        data.add(value);
        return this;
    }

    @Override
    public MyListVector insert(double value, int index) {
        if (index < 0 || index > size()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        data.add(index, value);
        return this;
    }

    @Override
    public MyListVector remove(int index) {
        if (index < 0 || index > size()) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        data.remove(index);
        return this;
    }

    @Override
    public MyListVector extract(int[] indices) {
        List<Double> newData = new ArrayList<>();
        for (int index : indices) {
            if (index < 0 || index >= size()) {
                throw new IndexOutOfBoundsException("Index out of bounds");
            }
            newData.add(data.get(index));
        }
        return new MyListVector(newData);
    }
}
