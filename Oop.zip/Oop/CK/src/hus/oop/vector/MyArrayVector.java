package hus.oop.vector;

import java.util.Arrays;

public class MyArrayVector extends AbstractMyVector {
    private static final int DEFAULT_CAPACITY = 8;
    private double[] data;
    private int size;

    /**
     * Khởi tạo mặc định cho vector.
     */
    public MyArrayVector() {
        this.data = new double[DEFAULT_CAPACITY];
        this.size = 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public double coordinate(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        return data[index];
    }

    @Override
    public double[] coordinates() {
        return Arrays.copyOf(data, size);
    }

    @Override
    public void set(double value, int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
       data[index] = value;
    }

    @Override
    public MyArrayVector add(double value) {
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i] + value;
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector add(MyVector another) {

        if (size != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i] + another.coordinate(i);
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector addTo(double value) {
        for (int i = 0; i < size; i++) {
            data[i] += value;
        }
        return this;
    }

    @Override
    public MyArrayVector addTo(MyVector another) {
        if (size != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        for (int i = 0; i < size; i++) {
            data[i] += another.coordinate(i);
        }
        return this;
    }

    @Override
    public MyArrayVector minus(double value) {
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i] - value;
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector minus(MyVector another) {
        if (size != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i] - another.coordinate(i);
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector minusFrom(double value) {
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = value - data[i];
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector minusFrom(MyVector another) {
        if (size != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = another.coordinate(i) - data[i];
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public double dot(MyVector another) {
        if (size != another.size()) {
            throw new IllegalArgumentException("Vectors must be of the same dimension");
        }
        double result = 0;
        for (int i = 0; i < size; i++) {
            result += data[i] * another.coordinate(i);
        }
        return result;
    }

    @Override
    public MyArrayVector pow(double power) {
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = Math.pow(data[i], power);
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public MyArrayVector scale(double value) {
        double[] newData = new double[size];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i] * value;
        }
        return new MyArrayVector(newData, size);
    }

    @Override
    public double norm() {
        double sum = 0;
        for (double d : data) {
            sum += d * d;
        }
        return Math.sqrt(sum);
    }

    @Override
    public MyArrayVector insert(double value) {
        if (size >= data.length) {
            enlarge();
        }
        data[size++] = value;
        return this;
    }

    @Override
    public MyArrayVector insert(double value, int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        if (size >= data.length) {
            enlarge();
        }
        System.arraycopy(data, index, data, index + 1,size - index);
        data[index] = value;
        size++;
        return this;
    }

    @Override
    public MyArrayVector remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }
        System.arraycopy(data, index + 1, data, index,size - index - 1);
        size--;
        return this;
    }

    @Override
    public MyArrayVector extract(int[] indices) {
        double[] newData = new double[indices.length];
        for (int i = 0; i < indices.length; i++) {
            if (indices[i] < 0 || indices[i] >= size) {
                throw new IndexOutOfBoundsException("Index out of bounds");
            }
            newData[i] = data[indices[i]];
        }
        return new MyArrayVector(newData, indices.length);
    }

    private MyArrayVector enlarge() {
        data = Arrays.copyOf(data, data.length * 2);
        return this;
    }

    private MyArrayVector(double[] data, int size) {
        this.data = data;
        this.size = size;
    }
}
