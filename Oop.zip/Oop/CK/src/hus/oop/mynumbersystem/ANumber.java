package hus.oop.mynumbersystem;

public class ANumber {
    private String numberPresentation;  // Biểu diễn số
    private int radix;                  // Cơ số


    public ANumber(String originalNumber, int radix) {
        this.numberPresentation = originalNumber;
        this.radix = radix;
    }

    public String getNumberPresentation() {
        return numberPresentation;
    }

    public void setNumberPresentation(String numberPresentation) {
        this.numberPresentation = numberPresentation;
    }

    public int getRadix() {
        return radix;
    }

    public void setRadix(int radix) {
        this.radix = radix;
    }

    // Thêm phương thức getValue và setValue
    public String getValue() {
        return numberPresentation;
    }
    public void setValue(String value) {
        this.numberPresentation = value;
    }
}