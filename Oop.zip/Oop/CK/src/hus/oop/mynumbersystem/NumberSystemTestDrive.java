package hus.oop.mynumbersystem;

import java.util.Scanner;

public class NumberSystemTestDrive {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the original number
        System.out.print("Enter the original: ");
        String originalNumber = scanner.nextLine();

        // Input the radix
        int radix;
        do {
            System.out.print("Enter the radix ( between 2 and 16): ");
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid radix. Please enter a number between 2 and 16.");
                scanner.next(); // Consume the invalid input
            }
            radix = scanner.nextInt();
        } while (radix < 2 || radix > 16);

        // Close the scanner
        scanner.close();

        // Create the ANumber object
        ANumber aNumber = new ANumber(originalNumber, radix);

        // Create converters
        NumberSystemConverter binaryConverter = new BinaryConverter(aNumber);
        NumberSystemConverter octalConverter = new OctalConverter(aNumber);
        NumberSystemConverter hexadecimalConverter = new HexadecimalConverter(aNumber);

        // Display the converted numbers
        System.out.println("Original number: " + originalNumber);
        System.out.println("Radix: " + radix);
        System.out.print("Binary: ");
        binaryConverter.display();
        System.out.print("Octal: ");
        octalConverter.display();
        System.out.print("Hexadecimal: ");
        hexadecimalConverter.display();
    }
}


