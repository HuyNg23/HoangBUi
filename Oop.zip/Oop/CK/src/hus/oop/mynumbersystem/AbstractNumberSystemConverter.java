package hus.oop.mynumbersystem;

import java.math.BigInteger;

public abstract class AbstractNumberSystemConverter implements NumberSystemConverter {
    protected ANumber originalNumber;
    protected String convertedNumber;         // Số được chuyển đổi theo cơ số nào đó từ số gốc

    public AbstractNumberSystemConverter(ANumber aNumber) {
        this.originalNumber = aNumber;
        this.convertedNumber = decimalTo(String.valueOf(aNumber.getValue()));
    }

    /**
     * Chuyển đổi số decimal từ hệ cơ số 10 thành số có hệ cơ số nào đó.
     * @param decimal
     * @return xâu ký tự biểu diễn một số trong hệ cơ số nào đó.
     *
     * Yêu cầu: sử dụng thuật toán Euclid để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     *
     * Gợi ý: có thể sử dụng lớp trung gian BigInteger để thuận lợi hơn cho việc tính toán.
     */

    public abstract String decimalTo(String decimal);

    /**
     * Chuyển đổi số được biểu diễn trong originalNumber sang biểu diễn số trong hệ cơ số 10.
     * @return xâu ký tự biểu diễn một số trong hệ cơ số 10.
     *
     * Yêu cầu: sử dụng thuật toán Horner để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     */

    public String toDecimal() {
        int radix = originalNumber.getRadix();
        String number = originalNumber.getValue() + "";
        BigInteger decimalValue = BigInteger.ZERO;
        BigInteger base = BigInteger.valueOf(radix);

        for (int i = 0; i < number.length(); i++) {
            int digit = Character.digit(number.charAt(i), radix);
            decimalValue = decimalValue.multiply(base).add(BigInteger.valueOf(digit));
        }

        return decimalValue.toString();
    }

    @Override
    public void update(ANumber number) {
        this.originalNumber = number;
        this.convertedNumber = decimalTo(toDecimal());
    }

    @Override
    public void display() {
        System.out.println(convertedNumber + "(" + originalNumber.getRadix() + ")");
    }
}
