package hus.oop.mynumbersystem;

import java.math.BigInteger;

public class BinaryConverter extends AbstractNumberSystemConverter {
    public BinaryConverter(ANumber aNumber) {
        super(aNumber);
    }

    /**
     * Chuyển đổi một số được biểu diễn trong hệ cơ số 10
     * sang số được biểu diễn trong hệ cơ số 2.
     * @param decimal
     * @return xâu ký tự biểu diễn số trong hệ cơ số 2.
     *
     * Yêu cầu: sử dụng thuật toán Euclid để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     */
    @Override
    public String decimalTo(String decimal) {
        BigInteger value = new BigInteger(decimal);
        StringBuilder binaryValue = new StringBuilder();

        while (value.compareTo(BigInteger.ZERO) > 0) {
            int remainder = value.mod(BigInteger.valueOf(2)).intValue();
            binaryValue.insert(0, remainder);
            value = value.divide(BigInteger.valueOf(2));
        }

        return binaryValue.length() > 0 ? binaryValue.toString() : "0";
    }

    /**
     * Cập nhật số được chuyển đổi khi số ban đầu thay đổi
     * hoặc cơ số của số ban đầu thay đổi.
     */
    @Override
    public void update(ANumber number) {
        this.originalNumber = number;
        this.convertedNumber = decimalTo(toDecimal());
    }

    /**
     * Hiển thị số ra terminal theo định dạng a1a2...an(2).
     */
    @Override
    public void display() {
        System.out.println(convertedNumber + "(" + originalNumber.getRadix() + ")");
    }
}
