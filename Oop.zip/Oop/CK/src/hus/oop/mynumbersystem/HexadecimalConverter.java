package hus.oop.mynumbersystem;

import java.math.BigInteger;

public class HexadecimalConverter extends AbstractNumberSystemConverter {
    public HexadecimalConverter(ANumber aNumber) {
        super(aNumber);
    }

    /**
     * Chuyển đổi một số được biểu diễn trong hệ cơ số 10
     * sang số được biểu diễn trong hệ cơ số 16.
     * @param decimal
     * @return xâu ký tự biểu diễn số trong hệ cơ số 16.
     *
     * Yêu cầu: sử dụng thuật toán Euclid để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     */
    @Override
    public String decimalTo(String decimal) {
        BigInteger value = new BigInteger(decimal);
        StringBuilder hexValue = new StringBuilder();

        while (value.compareTo(BigInteger.ZERO) > 0) {
            int remainder = value.mod(BigInteger.valueOf(16)).intValue();
            hexValue.insert(0, remainder < 10 ? (char) (remainder + '0') : (char) (remainder - 10 + 'A'));
            value = value.divide(BigInteger.valueOf(16));
        }

        return hexValue.length() > 0 ? hexValue.toString() : "0";
    }

    /**
     * Cập nhật số được chuyển đổi khi số ban đầu thay đổi
     * hoặc cơ số của số ban đầu thay đổi.
     */
    @Override
    public void update(ANumber number) {
        this.originalNumber = number;
        this.convertedNumber = decimalTo(toDecimal());
    }

    /**
     * Hiển thị số ra terminal theo định dạng a1a2...an(16).
     */
    @Override
    public void display() {
        System.out.println(convertedNumber + "(" + originalNumber.getRadix() + ")");
    }
}
